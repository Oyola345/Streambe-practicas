Los archivos principalmente relacionados con la consigna del trabajo 15 son:

-/src/pages/Home.js
-/src/styles/style.css
-/src/contexts/ThemeContext.js
-/src/components/ThemeToggle.js